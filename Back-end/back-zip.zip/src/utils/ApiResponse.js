module.exports = class ApiResponse {};
